/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/


#include <iostream>
#include <stdlib.h>
#include <string>
#include <iomanip>

#include "pizza.h"        //my header file

using namespace std;



Pizza::Pizza(){					//defaulth constructor
	this->name="Marqarita";
	this->size="medium";
	this->crust_type="normal";
	
	ingre_node* newingre = new ingre_node;
	newingre->ingredient_name = "mozarella";
	this->ingrehead = newingre;
	newingre->next = NULL;
}

Pizza::Pizza(Pizza &obj){				//copy constructor
	this->name=obj.name;
	this->size=obj.size;
	this->crust_type = obj.crust_type;
	ingre_node*traverse=obj.ingrehead;
	ingre_node* tail=NULL;
	while(traverse!=NULL){
		ingre_node* ing = new ingre_node;
		
		ing->ingredient_name = traverse->ingredient_name;
		ing->next=NULL;
		if(this->ingrehead==NULL){			//copying ingredients
			this->ingrehead = ing;
			tail=ing;
		}else{
			tail->next=ing;
			tail=ing;
		}
		traverse=traverse->next;
	}
	string remove;
	cout<<"Please enter the number of the ingredient you want to remove from your pizza"<<endl;
	traverse=this->ingrehead;
	int i=0;
	while(traverse!=NULL){
		cout<<i+1<<". "<<traverse->ingredient_name<<endl;
		i++;
		traverse=traverse->next;
	}
	string select_char;
	int select=1;
	cout<<"Press 0 to save it"<<endl;		//choosing which ingredient to remove;
	while(select!=0){
		cin>>select_char;
		while(select_char!="0" && select_char!="1" && select_char!="2" && select_char!="3" && select_char!="4" && select_char!="5" && select_char!="6"){
			cout<<"Wrong input, try again!"<<endl;
			cin>>select_char;
		}
		select = select_char[0]-'0';
	
		if(select!=0){
			if(this->name=="Chicken Pizza"){
				if(select==1){
					remove="mozarella";
				}else if(select==2){
					remove="chicken";
				}else if(select==3){
					remove="mushroom";
				}else if(select==4){
					remove="corn";
				}else if(select==5){
					remove="onion";
				}else if(select==6){
					remove="tomato";
					
				}else{
					remove="Wrong";
					cout<<"Wrong input"<<endl;
				}
				
				
				
			}else if(this->name=="Broccoli Pizza"){
				if(select==1){
					remove="mozarella";
				}else if(select==2){
					remove="broccoli";
				}else if(select==3){
					remove="pepperoni";
				}else if(select==4){
					remove="olive";
				}else if(select==5){
					remove="corn";
				}else if(select==6){
					remove="onion";
				}else{
					remove="Wrong";
					cout<<"Wrong input"<<endl;
				}
				
			}else if(this->name=="Sausage Pizza"){
				if(select==1){
					remove="mozarella";
				}else if(select==2){
					remove="sausage";
				}else if(select==3){
					remove="tomato";
				}else if(select==4){
					remove="olive";
				}else if(select==5){
					remove="mushroom";
				}else if(select==6){
					remove="corn";
				}else{
					remove="Wrong";
					
				}
			}
			tail=this->ingrehead;
			traverse=this->ingrehead;
			if(remove!="Wrong"){				//controlling input
				traverse=this->ingrehead;		
				while(traverse!=NULL && traverse->ingredient_name!=remove){	//searching ingredient
					tail=traverse;
					traverse=traverse->next;
				}
				if(traverse==NULL){						//may be it is already removed
					cout<<"This ingredient already removed"<<endl;
				}else{									//else deletion process
					if(this->ingrehead->next!=NULL){
						if(traverse==this->ingrehead){
							this->ingrehead=traverse->next;
							tail=this->ingrehead;
							delete traverse;
						}else{
							tail->next=traverse->next;
							delete traverse;
						}
					}else{								//we can not delete all ingredients
						cout<<"There must be remained at least 1 ingredient, so we can not remove "<<this->ingrehead->ingredient_name<<endl;
						break;
					}
				}
			}else{
				cout<<"Wrong input. Try again!"<<endl;
			}
		}else{
			break;
		}
	}

}

Pizza::Pizza(string size, string crust_type, int pizza_type){     //Pizza contructor
		string pizza_name;
		if(pizza_type==1){
			pizza_name ="Chicken Pizza";
		}else if(pizza_type==2){
			pizza_name = "Broccoli Pizza";
		}else if(pizza_type==3){
			pizza_name = "Sausage Pizza";
		}
		
		this->name=pizza_name;
		this->size = size;
		this->crust_type = crust_type;
		ingre_node* ptr;
		if(pizza_type==1){
			string* arr = new string[6] {"mozarella","chicken","mushroom", "corn", "onion", "tomato"};
			for(int i=0;i<6;i++){					//initialising all ingredients
				ingre_node* ing = new ingre_node;
				ing->ingredient_name=arr[i];
				if(i==0){
					ingrehead=ing;
					ptr=ingrehead;
					ptr->next=NULL;
				}else{
					ptr->next=ing;
					ptr=ptr->next;
					ptr->next=NULL;
				}
			}
			delete [] arr;						//arrays must be deleted as we allocate memory for them
		}else if(pizza_type==2){
			
			string* arr = new string[6] {"mozarella","broccoli","pepperoni","olive", "corn","onion"};
			for(int i=0;i<6;i++){					//initialising all ingredients
				ingre_node* ing = new ingre_node;
				ing->ingredient_name=arr[i];
				if(i==0){
					ingrehead=ing;
					ptr=ingrehead;
					ptr->next=NULL;
				}else{
					ptr->next=ing;
					ptr=ptr->next;
					ptr->next=NULL;
				}
			}
			delete [] arr;					//arrays must be deleted as we allocate memory for them
		}else if(pizza_type==3){
			string* arr = new string[6] {"mozarella","sausage","tomato","olive","mushroom","corn"};
			for(int i=0;i<6;i++){						//initialising all ingredients
				ingre_node* ing = new ingre_node;
				ing->ingredient_name=arr[i];
				if(i==0){
					ingrehead=ing;
					ptr=ingrehead;
					ptr->next=NULL;
				}else{
					ptr->next=ing;
					ptr=ptr->next;
					ptr->next=NULL;
				}
			}
			delete [] arr;				//arrays must be deleted as we allocate memory for them
		}
		
}


Order::Order(string const& customer_name,Pizza & headofpizzas2){			//Order constructor without drink
	this->customer=customer_name;
	this->headofpizzas=&headofpizzas2;
	this->headofdrinks=NULL;
	this->nextorder=NULL;
	cout<<"Name: "<<this->customer<<endl;
	Pizza* myptr=this->headofpizzas;
	cout<<endl;
	while(myptr!=NULL){												//printing newly constructed order
		//cout<<this->customer<<endl;
		cout<<myptr->getName();
		ingre_node* my_ingre=myptr->get_ingre_head();				
		cout<<"(";
		while(my_ingre!=NULL){
			cout<<my_ingre->ingredient_name<<", ";
			my_ingre=my_ingre->next;
		}
		cout<<")"<<endl;
		cout<<"size: "<<myptr->getSize()<<", ";
		cout<<"crust: "<<myptr->getCrust_type()<<endl;
		cout<<endl;
		myptr=myptr->getNextPizza();
	}
	cout<<endl;
	cout<<"-------------"<<endl;
		
	
}

Order::Order(string const& customer_name, Pizza & headofpizzas2, drink_order & drinkhead){			//Order constructor with drink		
	this->customer=customer_name;
	this->headofpizzas=&headofpizzas2;
	this->headofdrinks=&drinkhead;
	this->nextorder = NULL;
	Pizza* myptr=this->headofpizzas;
	cout<<"Name: "<<this->customer<<endl;
	cout<<endl;
	while(myptr!=NULL){											//printing newly constructed object 
		cout<<myptr->getName();
		ingre_node* my_ingre=myptr->get_ingre_head();
		cout<<"(";
		while(my_ingre!=NULL){
			cout<<my_ingre->ingredient_name<<", ";
			my_ingre=my_ingre->next;
		}
		cout<<")"<<endl;
		cout<<"size: "<<myptr->getSize()<<", ";					//printing its size
		cout<<"crust: "<<myptr->getCrust_type()<<endl;			//printing its crust_type
		cout<<endl;
		myptr=myptr->getNextPizza();
	}
	drink_order*control=this->headofdrinks;
	while(control!=NULL){										//printing drinks if there is
			cout<<control->drink_amount<<" "<<control->drink_name<<", ";
			control=control->next;
	}
	cout<<endl;
	cout<<"-------------"<<endl;
		
	
}

OrderList::OrderList(){				//OrderList constructor
	n=0;
	head=NULL;
}

double Order::getPrice(){						//calculating price function
	Pizza* pizza_ptr = this->headofpizzas;
	drink_order* drink_ptr = this->headofdrinks;
	double total_price=0;
	string sizeofpizza = pizza_ptr->getSize();
	while(pizza_ptr!=NULL){						//controlling pizza sizes
		if(sizeofpizza=="small"){
			total_price+=15;
		}else if(sizeofpizza=="medium"){
			total_price+=20;
		}else if(sizeofpizza=="big"){
			total_price+=25;
		}else{
			cout<<"There is not this kind of size option"<<endl;
		}
		pizza_ptr=pizza_ptr->getNextPizza();			//moving next pizza
	}
	if(drink_ptr!=NULL){
		while(drink_ptr!=NULL){							//controlling drinks
			if(drink_ptr->drink_name=="cola"){
				total_price=total_price+4*(drink_ptr->drink_amount);
			}else if(drink_ptr->drink_name=="soda"){
				total_price=total_price+2*(drink_ptr->drink_amount);
			}else if(drink_ptr->drink_name=="ice tea"){
				total_price=total_price+3*(drink_ptr->drink_amount);
			}else if(drink_ptr->drink_name=="fruit juice"){
				total_price=total_price+3.5*(drink_ptr->drink_amount);
			}
			drink_ptr=drink_ptr->next;				//moving next drink
		}
	}
	return total_price;			//finally returning total price
}


void Order::printOrder(){				//printing all orders with their pizzas
	Order* traverse = this;
	string our_customer;
	Pizza* pizza_ptr=traverse->headofpizzas;
	drink_order* drink_ptr= traverse->headofdrinks;
	ingre_node* ingre_ptr=pizza_ptr->get_ingre_head();
	cout<<endl;
	while(pizza_ptr!=NULL){
		
		cout<<pizza_ptr->getName()<<"(";
		ingre_ptr=pizza_ptr->get_ingre_head();
		while(ingre_ptr!=NULL){						//printing all ingredients of pizza
			cout<<ingre_ptr->ingredient_name<<", ";
			ingre_ptr=ingre_ptr->next;
		}
		cout<<")"<<endl;
		
		cout<<"size: "<<pizza_ptr->getSize()<<", ";     		//printing size of pizza
		cout<<"crust: "<<pizza_ptr->getCrust_type()<<endl;		//printing crust_type of pizza
		cout<<endl;
		pizza_ptr=pizza_ptr->getNextPizza();					//moving to next pizza
	}
	while(drink_ptr!=NULL){										//printing all of drinks 
		cout<<drink_ptr->drink_amount<<" "<<drink_ptr->drink_name<<", ";
		drink_ptr=drink_ptr->next;								//moving next drink
	}
			
	
		
}

void OrderList::listOrders(){									//lists all existing orders
	int i=1;
	Order* traverse = this->head;
	if(traverse!=NULL){
		while(traverse!=NULL){
			cout<<i<<endl;
			cout<<"------------"<<endl;
			cout<<"Name: "<<traverse->getCustomer()<<endl;
			traverse->printOrder();
			cout<<endl;
			cout<<"-------------"<<endl;
			i++;
			traverse=traverse->getNext();
		}
	}else{
		cout<<"There is no order to list"<<endl;
	}
}
Pizza::~Pizza(){							//Pizza destructor
	ingre_node* tail=this->ingrehead;
	while(this->ingrehead!=NULL){
		tail=this->ingrehead;				//deleting ingredients
		this->ingrehead=this->ingrehead->next;
		delete tail;
	}
	
}

Order::~Order(){							//Order destructor
	Pizza* tail;
	while(this->headofpizzas!=NULL){
		tail = this->headofpizzas;
		this->headofpizzas= this->headofpizzas->getNextPizza();
		delete tail;						//deleting all of pizzas 
	}
	drink_order*tail_of_drink;
	while(this->headofdrinks!=NULL){		//deleting drinks
		tail_of_drink = this->headofdrinks;
		this->headofdrinks = this->headofdrinks->next;
		delete tail_of_drink;
	}
}


void OrderList::deliverOrders(){				//delivering orders
	Order* traverse = this->head;
	Order* headoforders = traverse;
	Pizza* pizza_ptr=traverse->getHead();
	ingre_node* ingre_ptr=pizza_ptr->get_ingre_head();
	drink_order*drink_ptr = traverse->getDrinkHead();
	if(traverse!=NULL){							//controls if there is any order
		this->listOrders();						//printing orders
		
		string delivered_customer;
		cout<<"Please write the customer name in order to deliver his/her order: ";
		cin>>delivered_customer;
		traverse=headoforders;
		Order* tail = headoforders;
		while(traverse->getNext()!=NULL && traverse->getCustomer()!=delivered_customer){
			tail=traverse;
			traverse=traverse->getNext();
		}
		if(traverse->getCustomer()==delivered_customer){
			if(traverse->getCustomer()==headoforders->getCustomer()){
				headoforders = headoforders->getNext();
			}else{
				Order* any = traverse->getNext();
				tail->setNext(any);
			}
			pizza_ptr = traverse->getHead();
			drink_ptr = traverse->getDrinkHead();
			cout<<"Following order is delivering..."<<endl;
			cout<<"------------"<<endl;
			cout<<"Name: "<<delivered_customer<<endl;
			while(pizza_ptr!=NULL){
				cout<<pizza_ptr->getName();
				cout<<"(";
				ingre_ptr = pizza_ptr->get_ingre_head();
				while(ingre_ptr!=NULL){
					cout<<ingre_ptr->ingredient_name<<", ";
					ingre_ptr = ingre_ptr->next;
				}
				cout<<")"<<endl;
				cout<<"size: "<<pizza_ptr->getSize()<<", ";
				cout<<"crust: "<<pizza_ptr->getCrust_type()<<endl;
				drink_ptr = traverse->getDrinkHead();
				while(drink_ptr!=NULL){
					cout<<drink_ptr->drink_amount<<" "<<drink_ptr->drink_name<<", ";
					drink_ptr=drink_ptr->next;
				}
				pizza_ptr = pizza_ptr->getNextPizza(); 
			}
			string promotion;
			double price = traverse->getPrice();
			cout<<endl;
			cout<<"Total price: "<<price<<" TL"<<endl;
			string promotion_code="I am not a student";
			while(promotion_code!="I am a student"){
				cout<<"Do you have a promotion code? (y/n)"<<endl;
				cin>>promotion;
				
				if(promotion=="n"){
					cout<<"The order is delivered successfully!"<<endl;
					promotion_code="I am a student";
				}else if(promotion=="y"){
					cin.ignore(100,'\n');
					cout<<"Please enter your code: ";
					getline(cin,promotion_code);
					if(promotion_code=="I am a student"){
						//cout<<"Total price after promotion: "<<0.9*price<<" TL"<<endl;
						cout<<"Discounted price: "<<0.9*price<<" TL"<<endl;
					}
				}
			}
			this->head = headoforders;
			delete traverse;
			
		}else{
			//cout<<"There is no order taken by "<<delivered_customer<<endl;
			cout<<"Wrong name"<<endl;
		}
	}else{
		cout<<"There is no order"<<endl;
	}
	
}

OrderList::~OrderList(){			//Orderlist destructor
	Order* tail = this->head;
	while(this->head!=NULL){
		tail=this->head;
		this->head = this->head->getNext();		//deleting orders
		delete tail;
	}
}

Order* OrderList::takeOrder(){				//taking order from customer;
	string pizza_name;
	string size;
	string crust_type;
	string pizza_type_char;
	int pizza_type;
	int amount;

	cout<<"Pizza Menu"<<endl;
	cout<<"1. Chicken Pizza (mozarella, chicken, mushroom, corn, olive, onion, tomato)"<<endl;
	cout<<"2. Broccoli Pizza (mozarella, broccoli, pepperoni, olive, corn, onion)"<<endl;
	cout<<"3. Sausage Pizza (mozaralle, sausage, tomato, olive, mushroom, corn)"<<endl;
	cout<<"0. Back to main menu"<<endl;
	cin>>pizza_type_char;
	while(pizza_type_char!="1" && pizza_type_char!="2" && pizza_type_char!="3" && pizza_type_char!="0"){
		cout<<"you entered wrong input, try again! ";
		cin>>pizza_type_char;
		
	}
	pizza_type = pizza_type_char[0]-'0';	
	
	if(pizza_type!=0){
		size="notacceptable";
		while(size=="notacceptable"){
			cout<<"Select size: small (15TL), medium (20TL), big (25TL)"<<endl;
			cin>>size;
			if(size!="small" && size!="medium" && size!="big"){
				cout<<"You entered not existing size type, enter size again!"<<endl;
				size="notacceptable";
			}
		}
		crust_type="notacceptable";
		while(crust_type=="notacceptable"){
			cout<<"Select crust type: thin, normal, thick"<<endl;
			cin>>crust_type;
			if(crust_type!="thin" && crust_type!="normal" && crust_type!="thick"){
				cout<<"You entered not existing crust type, select crust type again!"<<endl;
				crust_type="notacceptable";
			}

		}
		amount=-1;
		string amount_char;
		while(amount<1){
			cout<<"Enter the amount:";
			cin>>amount_char;
			amount = stoi(amount_char);
			if(amount<1){
				cout<<"Amount can not be 0 or negative number"<<endl;
			}
		}
		
		Pizza* headofpizzas2=new Pizza(size, crust_type, pizza_type);		//constructor called
		Pizza *ptr2=headofpizzas2;
		Pizza* null = NULL;
		ptr2->setNextPizza(null);
		if(amount>1){
			for(int j=0;j<amount-1;j++){
				Pizza* newpizza=new Pizza(*headofpizzas2); //copy contructor called
				ptr2->setNextPizza(newpizza);
				ptr2=ptr2->getNextPizza();
				ptr2->setNextPizza(null);
			}
		}
		
		
		drink_order* drinkhead=NULL;		//choosing drinks
		drink_order* traverse=NULL;
		cout<<"Please choose a drink:"<<endl;
		cout<<"0. no drink"<<endl;
		cout<<"1. cola 4 TL"<<endl;
		cout<<"2. soda 2 TL"<<endl;
		cout<<"3. ice tea 3 TL"<<endl;
		cout<<"4. fruit juice 3.5 TL"<<endl;
		cout<<"Press -1 for save your order"<<endl;
		int choose=0;
		string choose_char;
		string which_drink;
		while(true){
			cin>>choose_char;
			while(choose_char!="-1" && choose_char!="0"&& choose_char!="1" && choose_char!="2" && choose_char!="3" && choose_char!="4"){
				cout<<"Wrong input, try again!"<<endl;
				cin>>choose_char;
			}
			if(choose_char=="-1"){
				choose=-1;
			}else{
				choose = choose_char[0]-'0';
			}
			
			if(choose==0){
				if(drinkhead==NULL){
					break;
				}else{
					traverse=drinkhead;
					drink_order* tail=drinkhead;
					while(traverse->next!=NULL){
						traverse=traverse->next;
						delete tail;
						tail=traverse;
					}
					delete tail;
					drinkhead=NULL;
					break;
				}
				
			}else{
				
				if(choose==-1){
					break;
				}
				//drink_order* drinkptr=new drink_order;
				if(choose==1){					//choosing which drink
					which_drink="cola";
				}else if(choose==2){
					which_drink="soda";
				}else if(choose==3){
					which_drink="ice tea";
				}else if(choose==4){
					which_drink="fruit juice";
				}else{
					which_drink="Wrong";
				}
				if(which_drink!="Wrong"){
					//drink_order* drinkptr=new drink_order;
					if(drinkhead==NULL){					//if it is first drink
						drink_order* drinkptr=new drink_order;
						drinkptr->drink_name=which_drink;
						drinkptr->drink_amount=1;
						drinkptr->next=NULL;
						drinkhead=drinkptr;
						traverse=drinkhead;
					}else{									// control if there alredy exist that drink or not
						drink_order*control=drinkhead;
						while(control->next!=NULL && control->drink_name!=which_drink){
							control=control->next;
						}
						if(control->drink_name==which_drink){		//if it is already exist increment number of drinktype
							control->drink_amount++;
						}else{
							drink_order* drinkptr=new drink_order;								
							drinkptr->drink_name=which_drink;
							drinkptr->drink_amount=1;
							traverse->next=drinkptr;
							drinkptr->next=NULL;
							traverse=traverse->next;
						}
					}
				}else{
					cout<<"You entered wrong number!"<<endl;
				}
			}
		}
		string customer_name;						//customer name
		cout<<"Please enter your name:"<<endl;
		cin>>customer_name;
		cout<<"Your order is saved, it will be delivered when it is ready..."<<endl;
		cout<<"------------"<<endl;
		Order* neworder;
		if(drinkhead!=NULL){						//if it has the drink
			neworder= new Order(customer_name,*headofpizzas2,*drinkhead);
			Order* null = NULL;
			neworder->setNext(null);
			return neworder;
		}else{										//else called another constructor without drink
			neworder= new Order(customer_name,*headofpizzas2);
			//neworder->nextorder=NULL;
			Order* null = NULL;
			(neworder)->setNext(null);//emin deyilem
			return neworder;

		}
		
	}else{
		return NULL;
	}
	
}



int main(){
	
	OrderList* orde = new OrderList;			//our MAIN menu 
	while(true){
		char whattodo;
		cout<<"Welcome to Unicorn Pizza"<<endl;
		cout<<"1. Add an order"<<endl;
		cout<<"2. List orders"<<endl;
		cout<<"3. Deliver order"<<endl;
		cout<<"4. Exit"<<endl;
		cout<<"Choose what to do: "<<endl;
		cin>>whattodo;
		
		Order* neworder;
		Order* traverse;
		if(whattodo=='1'){				//adding order
			
			neworder=orde->takeOrder();
			if(orde->getHead_order()==NULL){		//if it is first order
				orde->setHead_order(neworder);
				traverse=orde->getHead_order();
			}else{										//else
				traverse = orde->getHead_order();
				while(traverse->getNext()!=NULL){		//finding last order in order to add new order
					traverse=traverse->getNext();
				}
				traverse->setNext(neworder);			//adding it to list of orders
				
			}
		}else if(whattodo=='2'){							//listing orders, corresponding function is called
			if(orde->getHead_order()!=NULL){			//if there is an order
				orde->listOrders();
			}else{										//else prints empty
				cout<<"empty"<<endl;
			}
		}else if(whattodo=='3'){							//delivers order by calling corresponding function
			if(orde->getHead_order()!=NULL){			//if there is an order
				orde->deliverOrders();
			}else{										// else warns
				cout<<"There is no order to deliver"<<endl;
			}
		}else if(whattodo=='4'){							//exit 
			delete orde;								//before exit deletes orders if there exists
			cout<<"Goodbye..."<<endl;
			
			break;
		}else{
			cout<<"Wrong menu choice!"<<endl;
		}
	}
	return 0;
}

