/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/


#include <iostream>
#include <stdlib.h>
#include <string>
#include <iomanip>

using namespace std;

struct ingre_node{              //I store all ingredients of pizzas using this struct and construct linked-list
	string ingredient_name;
	ingre_node *next;
};

struct drink_order{             //All drinks are stored in linked-list type drink_order
	string drink_name;
	int drink_amount;
	drink_order *next;
};
class Pizza{                    //Class Pizza 
	private:
	string name;
	string size;
	ingre_node *ingrehead;
	string crust_type;
	Pizza *next;
	public:
	Pizza();						//Defaulth constructor
	Pizza(Pizza&);                  //copy constructor
	Pizza(string, string, int);     //Constructor
	~Pizza();                       //Destructor
	
	string getName(){				////////////////////////////////////
		return name;
	}
	void setName(string const& myname){
		name=myname;
	}
	Pizza* getNextPizza(){
		return next;
	}
	void setNextPizza(Pizza* const& newpizza2){
		next=newpizza2;
	}
	ingre_node* get_ingre_head(){			//All of this lines between two long comment lines are getters and setters  
		return ingrehead;
	}
	void set_ingre_head(ingre_node* const& newingre){
		ingrehead=newingre;
	}
	string getSize(){
		return size;
	}
	void setSize(string const& mysize){
		size=mysize;
	}
	string getCrust_type(){
		return crust_type;
	}
	void setCrust_type(string const&  my_crust_type){
		crust_type= my_crust_type;
	}									////////////////////////////////
};
class Order{
	private:
	string customer;							//customer of order
	Pizza * headofpizzas;						//all pizzas can be accesseble by this pointer ordered by customer
	
	drink_order* headofdrinks;					//all drinks can be accesseble by this pointer ordered by customer 
	Order* nextorder;							//pointer to next order
	public:
	double getPrice();							//gives total price of delivery
	void printOrder();							//prints orderlist
	///////////////////////////////////////////////////////////////////////////
	Pizza* getHead(){
		return headofpizzas;
	}
	void setHead(Pizza* const& newpizza2){
		headofpizzas=newpizza2;
	}
	Order* getNext(){
		 return nextorder;
	}
	void setNext(Order* const& neworder2){
		nextorder=neworder2;
	}
	string getCustomer(){				//All of this lines between two long comment lines are getters and setters
		return customer;
	}
	void setDrinkHead(drink_order* const& drink){
		headofdrinks = drink;
	}
	drink_order* getDrinkHead(){
		return headofdrinks;
	}
	void setNextNULL(){
		this->nextorder=NULL;
	}
	/////////////////////////////////////////////////////////////////////////
	//Order
	Order(string const&, Pizza &, drink_order &);		//contructor with drink
	Order(string const& , Pizza &);					//constructor without drink
	~Order();									//destructor
};

class OrderList{
	private:
	int n;//number of orders but I did not use it.
	Order *head;				//points to head of Orders
	public:
	OrderList();				//contructor
	~OrderList();				//destructor
	
	Order* takeOrder();				//takes new order
	void listOrders();				//lists existing orders
	void deliverOrders();			//delivers order
	////////////////////////////////////////////////////////////////////////
	Order* getHead_order(){
		return head;
	}
	void setHead_order(Order* const& neworder){			//All of this lines between two long comment lines are getters and setters
		head=neworder;
	}
	///////////////////////////////////////////////////////////////////////
};

