/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ 150180904.cpp -o main
//./main input.txt
///////////////////////////


#include <iostream>
#include <cmath>
#include <algorithm>
#include <string>
#include <fstream>

#include "150180904.h"

using namespace std;




void SigmoidNeuron::activate() {
	//cout << "activate Sig" << endl;                                           //I used this line for debugging 
	double x = this->activated_a;
	this->set_value_a((1 / (1 + exp(-x))));
}


/*SigmoidNeuron::~SigmoidNeuron() {
	cout << "SigmoidNeuron deleted" << endl;                                    //I used this for controlling memory leaks
}*/

/*SigmoidNeuron::SigmoidNeuron() {
	cout << "SigmoidNeuron created" << endl;                                    //I used this for controlling memory
}*/


/*Neuron::Neuron() {
	cout << "Neuron created" << endl;                                           //I used this for controlling memory
}*/



void ReluNeuron::activate() {
	//cout << "activate Relu" << endl;                                                  //I used this line for debugging  
	double x = this->activated_a;
	this->set_value_a(max(double(0), x));
}

/*ReluNeuron::~ReluNeuron() {
	cout << "ReluNeuron deleted" << endl;                                                //I used this for controlling memory leaks
}*/

/*ReluNeuron::ReluNeuron() {
	cout << "ReluNeuron created" << endl;                                                //I used this for contolling memory
}*/


/*LReluNeuron::~LReluNeuron() {
	cout << "LReluNeuron deleted" << endl;                                                 //I used this for controlling memory leaks 
}*/

/*LReluNeuron::LReluNeuron() {
	cout << "LReluNeuron created" << endl;                                                 //I used this for controlling memory
}*/

void LReluNeuron::activate() {
	//cout << "activate LRelu" << endl;                                                    // I used this line for debugging
	double x = this->activated_a;
	this->set_value_a(max(0.1*x, x));
}





Layer::~Layer() {
	//cout << "Layer deleted" << endl;                                                   //I used this line for checking memory leaks
	delete[] this->arr_neuron;

}

/*Layer::Layer() {
	cout << "Layer created" << endl;                                                   //I used this line for controlling memory
}*/



/*Network::~Network() {
	cout << "Network deleted" << endl;                                                        //I used this line for checking
}*/


Network::Network(const int& num_of_layers, int my_numofneurons[], int my_types[], int my_input_valus[]) {
	this->arr = new Layer[num_of_layers];
	for (int i = 0; i < num_of_layers; i++) {

		int num = my_numofneurons[i];
		Neuron** arr_neuron = new Neuron*[num];
		if (my_types[i] == 0) {
			arr[i].setarr_neuron(*(new SigmoidNeuron[num]));
		}
		else if (my_types[i] == 1) {
			arr[i].setarr_neuron(*(new LReluNeuron[num]));
		}
		else if (my_types[i] == 2) {
			arr[i].setarr_neuron(*(new ReluNeuron[num]));
		}

		if (i == 0) {
			for (int j = 0; j < my_numofneurons[i]; j++) {					//initialising first layer
				arr[i].getarr_neuron_index(j)->set_value_z(my_input_valus[j]);
			}
		}
		else {
			for (int j = 0; j < my_numofneurons[i]; j++) {			//initialising with 0.1
				arr[i].getarr_neuron_index(j)->set_value_z(0.1);
			}
		}

		delete[] arr_neuron;
	}

	for (int t = 0; t < my_numofneurons[0]; t++) {								//setting z values to activated values in first layer
		arr[0].getarr_neuron_index(t)->set_value_a(my_input_valus[t]);
	}
	for (int k = 0; k < num_of_layers - 1; k++) {

		double sum = 0;
		int h = 0;
		int steps = my_numofneurons[k];
		for (h = 0; h < steps; h++) {
			sum += arr[k].getarr_neuron_index(h)->get_value_a();
		}

		double my_z = sum * 0.1 + 0.1;
		int stepss = my_numofneurons[k + 1];

		for (int b = 0; b < stepss; b++) {								//setting activated value
			arr[k + 1].getarr_neuron_index(b)->set_value_a(my_z);
			arr[k + 1].getarr_neuron_index(b)->activate();
		}

	}
	for (int k = 0; k < num_of_layers; k++) {							//this loop for printing to the screen
		int num_of_step = my_numofneurons[k];
		cout << "Layer " << k << ":" << endl;
		for (int b = 0; b < num_of_step; b++) {
			cout << arr[k].getarr_neuron_index(b)->get_value_a() << endl;
		}

	}
	delete[] arr;														//releasing memory


}

int main(int argc,char**argv) {
	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);						//this line was for controlling memory leaks
	int num_of_layers;
	ifstream my_file;

	try{
		my_file.open(argv[1]);
		my_file>>num_of_layers;

		int *my_numofneurons = new int[num_of_layers+1];
		int *my_types = new int[num_of_layers+1];
		for (int h = 0; h < num_of_layers; h++) {
			my_file>>my_numofneurons[h];
		}
		for (int h = 0; h < num_of_layers; h++) {
			my_file>>my_types[h];
			if(my_types[h]!=0 && my_types[h]!=1 && my_types[h]!=2){
				delete [] my_numofneurons;
				delete [] my_types;
				string error="Unidentified activation function!"; 
				throw error;
			}
		}
	
		
		int *my_input_valus = new int[my_numofneurons[0]];
		for (int h = 0; h < my_numofneurons[0]; h++) {
			if(my_file.eof()){
				delete [] my_numofneurons;
				delete [] my_types;
				delete [] my_input_valus;
				string error = "Input shape does not match!";
				throw error;
			}
			my_file>>my_input_valus[h];
		}
		if(!(my_file.eof())){
			delete [] my_numofneurons;
			delete [] my_types;
			delete [] my_input_valus;
			string error = "Input shape does not match!";
			throw error;
		}

		Network N(num_of_layers, my_numofneurons, my_types, my_input_valus);
		delete [] my_numofneurons;
		delete [] my_types;
		delete [] my_input_valus;
	}
	catch (string error) {																	//If inputs have some problems, then error is printed.
		cout << error << endl;

	}

	//system("PAUSE");							//this was for visual studio
	return 0;
}
