/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/

//for compile and run
///////////////////////////
//g++ 150180904.cpp -o main
//./main input.txt
///////////////////////////


#include <iostream>
#include <cmath>
#include <algorithm>
#include <string>
#include <fstream>

using namespace std;



class Neuron {				//Neuron class
protected:
	double value_z;					//value before activation
	double activated_a;				//value after activation
public:
	virtual void activate() = 0;
	void set_value_z(const double& num) {
		this->value_z = num;
	}
	double get_value_z() {
		return value_z;
	}
	void set_value_a(const double& x) {
		activated_a = x;
	}
	double get_value_a() {
		return activated_a;
	}
	Neuron() {};
	virtual ~Neuron() {};
};


class SigmoidNeuron :public Neuron {
protected:

public:
	void activate();															//activate function for SigmoidNeuron class
	SigmoidNeuron() {};
	~SigmoidNeuron() {};

};

class ReluNeuron :public Neuron {
protected:
public:
	void activate();															//activate function for ReluNeuron class
	ReluNeuron() {};
	~ReluNeuron() {};
};


class LReluNeuron :public Neuron {
protected:

public:
	LReluNeuron() {};
	~LReluNeuron() {};
	void activate();																	 //activate function for LReluNeuron class
};


class Layer {
	//friend class Network;										//At first I wrote my code using friend, then I changed it to getter setter as I was not sure
private:
	Neuron* arr_neuron;
	//array of Neurons
public:
	//Layer(int my_inputs[], int num_of_layers, Layer* arr);
	const Neuron* getarr_neuron() {
		return arr_neuron;
	}

	Neuron *getarr_neuron_index(const int& index) {
		return &arr_neuron[index];
	}

	void setarr_neuron(Neuron&Obj) {
		this->arr_neuron = &Obj;
	}
	Layer() {};
	~Layer() ;
};

class Network {									//Network class
private:
	Layer* arr;
	//array of Layers
public:
	const Layer* get_network_arr() {
		return arr;
	}
	Network(const int& num_of_layers, int my_numofneurons[], int my_types[], int my_input_valus[]);
	~Network() {};
};

