/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/


//for compile and run
///////////////////////////
//g++ 150180904.cpp -c -o 150180904.o
//g++ main.cpp -c -o main.o
//g++ main.o 150180904.o -o prog
//./prog
/////////////////////////////



#include <iostream>
#include <string>

using namespace std;

class Person {                                                      // class Person is writen due to instructions in homework pdf
protected:
	string name;
	string surname;
public:
	string getName();
	string getSurname();
	Person(string const& my_name = "", string const& my_surname = "");		//constructor
	~Person(){};																//destructor
};


class Owner :public Person {												//Owner class is written due to homework pdf
protected:
	double ownership;				
	Owner *next_owner;
public:
	void setOwnership(double my_ownership) {								//function giving Business class access to datas of Owner
		this->ownership = my_ownership;
	}

	const double getOwnership() {											//function giving Business class access to datas of Owner
		return this->ownership;

	}
	Owner *getNextOwner() {													//function giving Business class access to datas of Owner
		return this->next_owner;
	}
	void setNextOwner(Owner & Obj) {										//function giving Business class access to datas of Owner
		this->next_owner = &Obj;
	}
	Owner(string const & my_name = "", string const & my_surname = "");		//constructor
	~Owner(){};																//destructor
};


class Courier :public Person {												//Courier class is written due to homework pdf
protected:
	string vehicle;
	Courier *next_courier;
	int transportation_capasity;
public:
	bool operator==(Courier & Obj2) {										//Overloading operator
		return this->getName() == Obj2.getName() && this->getSurname() == Obj2.getSurname() && this->getVehicle() == Obj2.getVehicle();
	}
	string getVehicle() {													//function giving Business class access to datas of Courier
		return vehicle;
	}
	void setNextCourier(Courier &Obj) {										//function giving Business class access to datas of Courier
		this->next_courier = &Obj;
	}
	Courier* giveNextCourier() {											//function giving Business class access to datas of Courier
		return this->next_courier;
	}
	void setNextNULL(){
		this->next_courier = NULL;
	}
	Courier(string const &, string const &, string const & vehicle = "");	//Constructor
	~Courier(){};																//destructor
};




class Business {									//Business class is created due to homework pdf
protected:
	string name;
	string address;
	Owner *owner_head;
	Courier *courier_head;
	int index;
public:
	Business(string const &business_name, string const &business_address, Owner* owner_array, int number_of_owners);	//constructor
	~Business(){};																										//destructor
	void const hire_courier(Courier &);
	void const fire_courier(Courier &);
	void const list_couriers();
	void const list_owners();
	int const calculate_shipment_capacity();
	
	void operator()() {					//overloading () operator
		cout << this->name << " ";
		cout << this->address << endl;
		this->list_owners();
		this->list_couriers();
	}
	
	Courier& operator[] (int);			//overloading [] operator

};

