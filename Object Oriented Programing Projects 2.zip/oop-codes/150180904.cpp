/* @Author
Student Name: Elvin Abdinli
Student ID: 150180904*/


//for compile and run
///////////////////////////
//g++ 150180904.cpp -c -o 150180904.o
//g++ main.cpp -c -o main.o
//g++ main.o 150180904.o -o prog
//./prog
/////////////////////////////



#include <iostream>
#include <string>

#include "150180904.h"
using namespace std;


string Person::getName() {													//function giving Business class access to datas of Person
	return name;
}

string Person::getSurname() {												//function giving Business class access to datas of Person
	return surname;
}

Owner::Owner(string const & my_name, string const & my_surname) {
	next_owner = NULL;
	name = my_name;
	surname = my_surname;
	//cout << "Owner created" << endl;			//This comment was for checking memory by me
}
/*
Owner::~Owner() {
	cout << "Owner deleted" << endl;			//This comment was for checking memory by me

}*/


Person::Person(string const &my_name, string const &my_surname) {
	//cout << "Person created" << endl;			//This comment was for checking memory by me
	name = my_name;
	surname = my_surname;

}
/*
Person::~Person() {
	cout << "Person deleted" << endl;			//This comment was for checking memory by me

}*/

// Constructor parameters: name, surname, vehicle_type
Courier::Courier(string const &my_name, string const &my_surname, string const& my_vehicle) {
	next_courier = NULL;
	//cout << "Courier created" << endl;		//This comment was for checking memory by me
	if (my_vehicle != "car" && my_vehicle != "bicycle" && my_vehicle != "motorcycle") {		//checking input
		cout << "Invalid input!" << endl;
	}
	else {
		vehicle = my_vehicle;
		name = my_name;
		surname = my_surname;
		next_courier = NULL;
		//cout << "Courier created" << endl;						//this comment was for checking memory by me
	}

}
/*
Courier::~Courier() {
	cout << "Courier deleted" << endl;				//This comment was for checking memory by me

}*/


//Constructor parameters: name, address, owner_array, number_of_owners
Business::Business(string const &business_name, string const &business_address, Owner* owner_array, int  number_of_owners)
{
	owner_head = NULL;
	courier_head = NULL;
	name = business_name;
	address = business_address;			// assigning initial values to business
	Owner * owner_ptr = owner_head;
	if (owner_head != NULL) {
		while (owner_ptr->getNextOwner() != NULL) {
			owner_ptr = owner_ptr->getNextOwner();
		}
	}
	for (int i = 0; i < number_of_owners; i++) {			//adding owners from array to the list
		if (owner_head == NULL) {
			owner_head = &owner_array[i];
			owner_ptr = owner_head;
			owner_ptr->setOwnership(100 / number_of_owners);

		}
		else {
			owner_ptr->setNextOwner(owner_array[i]);
			owner_ptr = owner_ptr->getNextOwner();
			owner_ptr->setOwnership(100 / number_of_owners);
		}

	}

}


void const Business::fire_courier(Courier & Obj2) {				//fires couriers from the list
	Courier *traverse_ptr = courier_head;
	Courier *courier_ptr = courier_head;
	while (courier_ptr != NULL) {
		if ((*courier_ptr) == (Obj2)) {						//overloaded operation== is called
			if (courier_ptr == courier_head) {
				courier_head = courier_head->giveNextCourier();
				courier_ptr->setNextNULL();		
				break;
			}
			else {
				traverse_ptr->setNextCourier(*courier_ptr->giveNextCourier());
				courier_ptr->setNextNULL();
				break;
			}

		}
		traverse_ptr = courier_ptr;
		courier_ptr = courier_ptr->giveNextCourier();
	}
	if(courier_ptr==NULL){
		cout<<"This courier is not in the list"<<endl;
	}

}


Courier& Business::operator[](int number) {					//overloading operator[]
	int i = 0;
	Courier *courier_ptr = courier_head;
	while (i < number) {
		courier_ptr = courier_ptr->giveNextCourier();
		i++;
	}
	return *courier_ptr;
}


void const Business::hire_courier(Courier & Obj) {				//function hiring couriers
	if (courier_head != NULL) {
		Courier * c_ptr = courier_head;
		while (c_ptr->giveNextCourier() != NULL) {
			c_ptr = c_ptr->giveNextCourier();
		}
		if(Obj.getVehicle()=="car" || Obj.getVehicle()=="motorcycle" || Obj.getVehicle()=="bicycle"){
			c_ptr->setNextCourier(Obj);
		}else{
			cout<<"Wrong input can not be added to the list!"<<endl;
		}
	}
	else {
		//courier_head = &Obj;
		if(Obj.getVehicle()=="car" || Obj.getVehicle()=="motorcycle" || Obj.getVehicle()=="bicycle"){
			courier_head = &Obj;
		}else{
			cout<<"Wrong input can not be added to the list!"<<endl;
		}
	}
}

void const Business::list_owners() {						//function listing owners
	if (owner_head != NULL) {								//controlling if list empty or not 
		Owner *owner_ptr = owner_head;
		while (owner_ptr != NULL) {
			cout << owner_ptr->getName() << " " << owner_ptr->getSurname() << " " << owner_ptr->getOwnership() << endl;
			owner_ptr = owner_ptr->getNextOwner();
		}
	}
	else {
		cout << "There is no owner to list" << endl;
	}
}

void const Business::list_couriers() {						//functions listing couriers
	if (courier_head != NULL) {								//controlling if list empty or not
		Courier * courier_ptr = courier_head;
		while (courier_ptr != NULL) {
			cout << courier_ptr->getName() << " " << courier_ptr->getSurname() << " " << courier_ptr->getVehicle() << endl;
			courier_ptr = courier_ptr->giveNextCourier();
		}
	}
	else {
		cout << "There is no courier to list" << endl;
	}
}

int const Business::calculate_shipment_capacity() { 			//calculating shipment capasity each bicycle->10, each motorcycle-> 35, each car->200.
	Courier * courier_ptr = courier_head;
	int shipment_capacity = 0;
	while (courier_ptr != NULL) {

		if (courier_ptr->getVehicle() == "bicycle") {
			shipment_capacity += 10;
		}
		else if (courier_ptr->getVehicle() == "motorcycle") {
			shipment_capacity += 35;
		}
		else if (courier_ptr->getVehicle() == "car") {
			shipment_capacity += 200;
		}
		courier_ptr = courier_ptr->giveNextCourier();
	}
	return shipment_capacity;
}


